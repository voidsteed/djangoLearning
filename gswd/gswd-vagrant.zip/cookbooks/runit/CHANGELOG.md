## v0.16.0:

* [COOK-794] default logger and `no_log` for `runit_service`
  definition
* [COOK-1165] - restart functionality does not work right on Gentoo
  due to the wrong directory in the attributes
* [COOK-1440] - Delegate service control to normal user

## v0.15.0:

* [COOK-1008] - Added parameters for names of different templates in runit
