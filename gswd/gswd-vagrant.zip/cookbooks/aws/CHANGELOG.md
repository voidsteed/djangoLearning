## v0.100.2:

* [COOK-1568] - switch to chef_gem resource
* [COOK-1426] - declare default actions for LWRPs

## v0.100.0:

* [COOK-1221] - convert node attribute accessors to strings
* [COOK-1195] - manipulate AWS resource tags (instances, volumes,
  snapshots
* [COOK-627] - add aws_elb (elastic load balancer) LWRP
